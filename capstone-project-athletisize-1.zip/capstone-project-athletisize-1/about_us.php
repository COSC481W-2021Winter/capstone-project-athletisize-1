<?php
  include_once 'header.php';
?>


<html>
    <head>
        <title>About us</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <<link rel="stylesheet" href="project.css"/>>
    </head>

    <body>
        <section class="about">
            <h1>About us</h1>
            <h2>Her name is Ashley Scott, she is 7 years old..She plays on her school team. The coach teaches her soccer. 
                The coach only communicates with the parents when there is a practice or a game coming up, when told to buy equipment, 
                the coach didn’t state what kind or where to buy it from. She only plays at practice and at games.

                Ashley doesn’t have any equipment to store anywhere because they haven’t bought any yet. 
                But when she does eventually get her equipment, they will keep it in the family’s minivan. 
                When she goes to use the equipment, it will most likely be at soccer practice or at a game. 
                She does not have any friends on the team yet, because the season hasn’t started yet and she 
                has never played before. Though she doesn’t have any friends yet, most of the other players 
                in her league just buy their equipment from places like Dick’s Sporting Goods.
            </h2>
            <img src="kids.jpg" alt="kids playing soccer" width="900" height="400">
        </section>
    </body>
</html>

<?php
  include_once 'footer.php';
?>