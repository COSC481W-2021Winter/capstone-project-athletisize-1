<?php
  include_once 'header.php';
?>

<html>
    <head>
        <title>Sports - Soccer</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="project.css"/>
    </head>

    <body>
        <section>
            <h1 class="info">Soccer</h1>
			<h2 class="sportlisthead">Player</h2>
				<ul class="sportlist">
					<li>Cleats</li>
					<li>Shin Guards</li>
					<li>Athletic Socks</li>
				</ul>
			<h2 class="sportlisthead">Goalie</h2>
				<ul class="sportlist">
					<li>Goalie Gloves</li>
				</ul>
        </section>
    </body>
</html>

<?php
  include_once 'footer.php';
?>