# capstone-project-athletisize-1
capstone-project-athletisize-1 created by GitHub Classroom


Weekly meeting times: Fridays @ 4:00pm
Team Name: AthletiSize
Project Name: AthletiSize

<br>
<b><u>Description of Prototype</b></u><br>
1. Users will arrive at our home page, where they can log in or sign up for an account, or just get started quickly as an anonymous user<br>
2. The Home page also has a toolbar at the top for a listing of sports and the required equipment for each, an about us page, contact us page, and a home button to return back to the home screen<br>
3. Clicking "Sports" will take the user to a page where they will get a list of sports, where they can choose one and it will give a listing of all of the required equipment for that sport. <br>
4. The "About Us" page will be a short description of our product and team, along with bios of each team member. "Contact Us" will have our contact information.<br>
5. The web interface will be HTML/CSS based, with some Javascript elements, and the back end will feature a PHP/SQL database. For the prototype we will only have a small table with ~10 users, as well as a table for each sport, and basic framework for the static elements of the website. <br>




Persona

Name: Michael Scott
Age: 28
Location: Ann Arbor, Michigan
Occupation: Sales representative 
Busy single Dad


<img src="GettyImages-1030913102-1.jpg" width="130" height="130" align="left" /><br>

<br>
<br>
<br>

<br>Screening Questions:
What sport do they play?
Are they a beginner or have they previously played?
Height, weight, shoe size, age?

Michael Scott is a busy single father who has a daughter playing soccer for the first time. He has never played organized sports and doesn’t have many friends who do, or have children in any sports leagues. Knowing he has to buy equipment for his daughter, he has no resources on how to figure out what exactly he needs to buy, and what sizes he would need as well as limited time. He wants to make sure that he is purchasing the correct gear at the right price but doesn’t have time to go into a store and doesn’t want to waste time talking to a sales representative.

Values: Lack of experience/knowledge on sports equipment, busy lifestyle

Update questions:
How old is his daughter? (It's not in GitHub.) What's her name? Where does she play? Who teaches her soccer? Is her couch nice? Does the coach communicate with the parents often? How often does she play? Where would she store/use all her equipment? Does she have any friends who play, too? Where do her friends buy the equipment?

Her name is Ashley Scott, she is 7 years old..She plays on her school team. The coach teaches her soccer. The coach only communicates with the parents when there is a practice or a game coming up, when told to buy equipment, the coach didn’t state what kind or where to buy it from. She only plays at practice and at games. 

Ashley doesn’t have any equipment to store anywhere because they haven’t bought any yet. But when she does eventually get her equipment, they will keep it in the family’s minivan. When she goes to use the equipment, it will most likely be at soccer practice or at a game. She does not have any friends on the team yet, because the season hasn’t started yet and she has never played before. Though she doesn’t have any friends yet, most of the other players in her league just buy their equipment from places like Dick’s Sporting Goods.

