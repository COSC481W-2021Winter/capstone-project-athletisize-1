<?php
  include_once 'header.php';
?>
<html>
    <head>
        <title>Log in</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="project.css"/>
    </head>

    <body>

        <div class="login">
            <h1>Log in</h1>
            <form class="wrapper">
                <div class="user">
                    <label>username</label>
                    <input type="text" placeholder="username" required>
                </div>
                <div class="password">
                    <label>password</label>
                    <input type="password" placeholder="password" required>
                </div>
                <input class="btn" type="submit" value="login">
                <a href="C:\Users\aghal\Desktop\481 project\project.html"><h2>forgot password?</h2></a>
                <a href="C:\Users\aghal\Desktop\481 project\project.html"><h3>Not a user? click here to sign up</h3></a>
            </form>
        </div>


        
    </body>
</html>

<?php
  include_once 'footer.php';
?>
