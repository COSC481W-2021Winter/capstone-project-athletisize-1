<?php
  include_once 'header.php';
?>

<html>
    <head>
        <title>Contact us</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <<link rel="stylesheet" href="project.css"/>>
    </head>

    <body>
        <section class="contact">
            <h1>Contact us</h1>
            <h2>Email: aghaleb1@emich.edu. <br> 
                Phone Number:  917-633-9974. <br>
                Best time to contact: 8am-5pm.
            </h2>
        </section>
    </body>
</html>

<?php
  include_once 'footer.php';
?>