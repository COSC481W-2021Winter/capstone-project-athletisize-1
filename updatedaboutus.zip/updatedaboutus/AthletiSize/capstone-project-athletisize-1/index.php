<?php
  include_once 'header.php';
?>

    <body>
        
        <div id="hometop"></div>
        <section >
            <div class="sec">
                <h1>Welcome to ATHLETISIZE!</h1>
            </div>
            <img class="image1" src="b.jpg" alt="Sports" width="1000" height="500">
            <h4 class="info">Michael Scott is a busy single father who has a daughter
                playing soccer for the first time. He has never played organized sports 
                and doesn’t have many friends who do, or have children in any sports leagues. 
                Knowing he has to buy equipment for his daughter, he has no resources on how to
                 figure out what exactly he needs to buy, and what sizes he would need as well as 
                 limited time. He wants to make sure that he is purchasing the correct gear at the
                  right price but doesn’t have time to go into a store and doesn’t want to waste 
                  time talking to a sales representative.<br>
                  <span class="getinfo">Need information without contacting a sales representative? <br>
                  click the button below!
                 </span>
            </h4>
            <a href="#" class="started"><button>Get Started!</button></a>
        </section>
    </body>

<?php
  include_once 'footer.php';
?>
