<?php
  include_once 'header.php';
?>

<html>
    <head>
        <title>Sports - Lacrosse</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="project.css"/>
    </head>

    <body>
        <section>
            <h1 class="info">Lacrosse</h1>
				<ul class="sportlist">
					<li>Helmet</li>
					<li>Shoulder Pads</li>
					<li>Arm Guards</li>
					<li>Gloves</li>
					<li>Cleats</li>
					<li>Stick</li>
					<li>Mouth Guard</li>
					<li>Protective Cup</li>
				</ul>
        </section>
    </body>
</html>

<?php
  include_once 'footer.php';
?>