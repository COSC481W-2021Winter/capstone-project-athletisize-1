<?php
  include_once 'header.php';
?>

<html>
    <head>
        <title>Sports - Cross Country Ski</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="project.css"/>
    </head>

    <body>
        <section>
            <h1 class="info">Cross Country Ski</h1>
				<ul class="sportlist">
					<li>Skis</li>
					<li>Boots</li>
					<li>Poles</li>
					<li>Goggles</li>
				</ul>
        </section>
    </body>
</html>

<?php
  include_once 'footer.php';
?>